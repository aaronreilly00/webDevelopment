(document).ready(function(){
   (".button").click(function(){
       (".itemp").hide();
   });
});

