var express = require("express");
var app = express();
const path = require("path");
const VIEWS = path.join(__dirname, 'views');

// REMOVE THIS TO GET THE JADE view engine rendering pages without .jade extensions
app.set("view engine", "jade");

// in order to the express app to look info in specific directories: like css, images, javascripts
app.use(express.static("scripts")); //allow the application access the scripts folder contents to use in the app
app.use(express.static("images")); //allow the application access the images folder contents to use in the app
app.use(express.static("styles")); //allow the application access the images folder contents to use in the app
app.use(express.static("views"));

// Add the body-parser module in order to be able to handle request like: POST when click on a buton to send 
// the information contained on a Form with values of your i.e: new products
//var bodyParser = require("body-parser");
//app.use(bodyParser.urlencoded({extended: true}));

app.get('/', function(req, res){
    res.render('index',{root:VIEWS});
    console.log("Jade home");
});

app.get('/products', function(req, res){
    res.render('products',{root:VIEWS});
    console.log("Jade products");
});

// app.get('/road', function(req, res){
//     res.render('road',{root:VIEWS});
//     console.log("Jade road!");
// });

app.get('/mountain', function(req, res){
    res.render('mountain',{root:VIEWS});
    console.log("Jade mountain!");
});

app.get('/accessories', function(req, res){
    res.render('accessories',{root:VIEWS});
    console.log("Jade accessories!");
});

app.get('/services', function(req, res){
    res.render('services',{root:VIEWS});
    console.log("services!");
});

//this code provides the server port for our application to run on
app.listen(process.env.PORT || 3000, process.env.IP || "0.0.0.0", function(){
    console.log("App is running......Yesss!");
});

// access a mysql database
var mysql = require("mysql");

//function to set a simple hello response from the database
const db = mysql.createConnection({
    host: "den1.mysql3.gear.host",
    user: "webdev2",
    password: "Nm0JS9J_b!9X",
    database: "webdev2"
});

db.connect((err) => {
    if(err) {
        //console.log("Bad luck! Connection refused!!!!.....")
        throw(err)
    }
    else {
        console.log("Well done you are connected.....")
    }
});

// Create a Database Table
app.get("/createtable",function(req,res){
    let sql = 'CREATE TABLE products(Id int NOT NULL AUTO_INCREMENT PRIMARY KEY, Image varchar(255), Make varchar(255), Model varchar(255), Price int);'
    let query = db.query(sql,(err,res)=>{
       if (err) throw err;
       console.log(res);
    });
    res.send("createtable ....Table created!")
});

// SQL Insert into a table
app.get("/insert",function(req,res){
    let sql = 'INSERT INTO products (Image, Make, Model, Price) VALUES ("fuji1.jpg", "Fuji", "SL 2.3 Disc Road Bike", 1600), ("fuji2.jpg", "Fuji", "Roubaix 1.1 Disc Road Bike", 1200), ("Vitus1.jpg", "Vitus", "Razor VR Road Bike", 720), ("Vitus2.jpg", "Vitus", "Vitesse Evo Road Bike", 720), ("kona1.jpeg", "Kona", "Rove NRB Adventure", 1080) ;'
    let query = db.query(sql,(err,res)=>{
       if (err) throw err;
       console.log(res);
    });
    res.send("insert ....Item created!")
});

app.get('/road',function(req,res) {
// UNCOMMENT THIS TO GET all THE PRODUCTS previously INSERTED IN DATABASE DISPLAYED IN THE PRODUCT PAGE
    let sql = 'SELECT * FROM products;'
    console.log("inside")
    let query = db.query(sql, (err,res1) =>{
        if (err) throw err;
        res.render('road',{root:VIEWS, res1}); // USE RENDER COMMAND SO THAT THE RESPONSE OBJ renders an HTML page
    });
    console.log("JADE Now you are on the products page!...")
});