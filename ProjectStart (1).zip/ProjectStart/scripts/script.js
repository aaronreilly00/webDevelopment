$(document).ready(function(){
   $(".bikeInfo").click(function(){
       $(".f1show").slideToggle(1000);
   });
});