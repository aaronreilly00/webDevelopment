var express = require("express"); // call the express module which is default provided by Node
var app = express(); // now we neeed to declare our app which is the envoked express application
const path = require("path");
const VIEWS = path.join(__dirname,'views');

// setup a simple hello world application unsing the request and response function
app.get('/', function(req,res) {
  res.sendFile('index.html',{root:VIEWS}); // we set the response to send back the string hello world
  console.log('Now you are home!'); // used to output activity in the console
});

//this code provides the server port for our application to run on
app.listen(process.env.PORT || 3000, process.env.IP || "0.0.0.0", function() {
  console.log("Yippee....... its runing");
});
