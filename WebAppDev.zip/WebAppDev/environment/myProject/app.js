var express = require("express");
var app = express();
const path = require("path");
const VIEWS = path.join(__dirname, 'views');

// in order to the express app to look info in specific directories: like css, images, javascripts
app.use(express.static("scripts")); //allow the application access the scripts folder contents to use in the app
app.use(express.static("images")); //allow the application access the images folder contents to use in the app
app.use(express.static("styles")); //allow the application access the images folder contents to use in the app

app.get('/', function(req, res){
    res.sendFile('index.html',{root:VIEWS});
    console.log("Now you are home!");
});

app.get('/products', function(req, res){
    res.sendFile('products.html',{root:VIEWS});
    console.log("products!");
});

//this code provides the server port for our application to run on
app.listen(process.env.PORT || 3000, process.env.IP || "0.0.0.0", function(){
    console.log("App is running......Yesss!");
});