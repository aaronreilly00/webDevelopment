var express = require("express");
var app = express();
const path = require("path");
const VIEWS = path.join(__dirname, 'views');

// REMOVE THIS TO GET THE JADE view engine rendering pages without .jade extensions
app.set("view engine", "jade");


// Add the body-parser module in order to be able to handle request like: POST when click on a buton to send 
// the information contained on a Form with values of your i.e: new products
var bodyParser = require("body-parser");
app.use(bodyParser.urlencoded({extended: true}));


var mysql = require("mysql");


// in order to the express app to look info in specific directories: like css, images, javascripts
app.use(express.static("scripts")); //allow the application access the scripts folder contents to use in the app
app.use(express.static("images")); //allow the application access the images folder contents to use in the app
app.use(express.static("styles")); //allow the application access the images folder contents to use in the app


//function to set a simple hello response from the database
const db = mysql.createConnection({
    host: "den1.mysql3.gear.host",
    user: "webdev2",
    password: "Nm0JS9J_b!9X",
    database: "webdev2"
});

db.connect((err) => {
    if(err) {
        //console.log("Bad luck! Connection refused!!!!.....")
        throw(err)
    }
    else {
        console.log("Well done you are connected.....")
    }
});

// Create a Database Table
app.get("/createtable",function(req,res){
    let sql = 'CREATE TABLE products(Id int NOT NULL AUTO_INCREMENT PRIMARY KEY, Name varchar(255), Price int, Image varchar(255), Activity varchar(255));'
    let query = db.query(sql,(err,res)=>{
       if (err) throw err;
       console.log(res);
    });
    res.send("createtable ....Table created!")
});
// End careate table

// SQL Insert into a table
app.get("/insert",function(req,res){
    let sql = 'INSERT INTO products (Name, Price, Image, Activity) VALUES ("Polar M400", 199, "polarM400.png", "Running");'
    let query = db.query(sql,(err,res)=>{
       if (err) throw err;
       console.log(res);
    });
    res.send("insert ....Item created!")
});
// End Insert into a table

// function to set access to root home html page
app.get('/',function(req,res) {
    res.render('index',{root:VIEWS});
    console.log("JADE You are at the home page!...")
});
// End root html page

// function to set access to products html page
app.get('/products',function(req,res) {
// UNCOMMENT THIS TO GET all THE PRODUCTS previously INSERTED IN DATABASE DISPLAYED IN THE PRODUCT PAGE
    let sql = 'SELECT * FROM products;'
    let query = db.query(sql, (err,res1) =>{
        if (err) throw err;
        res.render('products',{root:VIEWS, res1}); // USE RENDER COMMAND SO THAT THE RESPONSE OBJ renders an HTML page
    });
    console.log("JADE Now you are on the products page!...")
});
// End products html page

// THIS NEXT TWO ROUTES WORK TOGETHER: One for the GET "app.get" and 
// one for the POST "app.post" requests TO CREATE A NEW PRODUCT
// function to set access to new product html page
app.get('/create',function(req,res) {
    res.render('create',{root:VIEWS});
    console.log("JADE You are at New product page!...")
});
// End new products html page

// function to set access to new product html page
app.post('/create',function(req,res) {
    let sql = 'INSERT INTO products (Name, Price, Image, Activity) VALUES ("'+req.body.name+'", '+req.body.price+', "'+req.body.image+'", "'+req.body.activity+'");'
    let query = db.query(sql,(err,res)=>{
       if (err) throw err;
       console.log(res);
    });
    console.log("JADE New product inserted..."+req.body.name);
    res.render('index',{root:VIEWS});
});
// End new products html page

// THIS NEXT TWO ROUTES WORK TOGETHER: One for the GET "app.get" and 
// one for the POST "app.post" requests TO EDIT A SPECIFIC PRODUCT
// function to set access to new product html page
app.get('/edit/:id',function(req,res) {
// UNCOMMENT THIS TO GET all THE PRODUCTS previously INSERTED IN DATABASE DISPLAYED IN THE PRODUCT PAGE
    let sql = 'SELECT * FROM products WHERE Id = "'+req.params.id+'";'
    let query = db.query(sql, (err,res1) =>{
        if (err) throw err;
        res.render('edit',{root:VIEWS, res1}); // USE RENDER COMMAND SO THAT THE RESPONSE OBJ renders an HTML page
    });
    console.log("JADE Now you are on the edit item page!...")
});
// End new products html page

// function to set access to new product html page
app.post('/edit/:id',function(req,res) {
    let sql = 'UPDATE products SET Name = "'+req.body.newname+'", Price = "'+req.body.newprice+'", Image = "'+req.body.newimage+'", Activity = "'+req.body.newactivity+'" WHERE Id = "'+req.params.id+'";'
    let query = db.query(sql,(err,res)=>{
       if (err) throw err;
       console.log(res);
    });
    console.log("JADE New product updated..."+req.body.name);
    res.redirect('/item/' + req.params.id);
});
// End new products html page

// function to render an individual item from the products html page
app.get('/item/:id',function(req,res) {
// UNCOMMENT THIS TO GET all THE PRODUCTS previously INSERTED IN DATABASE DISPLAYED IN THE PRODUCT PAGE
    let sql = 'SELECT * FROM products WHERE Id = "'+req.params.id+'";'
    let query = db.query(sql, (err,res1) =>{
        if (err) throw err;
        res.render('item',{root:VIEWS, res1}); // USE RENDER COMMAND SO THAT THE RESPONSE OBJ renders an HTML page
    });
    console.log("JADE Now you are on the individual item page!...")
});
// End showing individual product html page

// function to delete database recrd on button press and form
app.get('/delete/:id', function(req, res){
   let sql = 'DELETE FROM products WHERE Id = "'+req.params.id+'";'
   let query = db.query(sql, (err, res1) =>{
       if(err) throw(err);
       res.redirect('/products'); // use the render command so that the response object renders a HHTML page
   });
   console.log("JADE Now you deleted the product and Its Gone!");
});
// End delete product


//this code provides the server port for our application to run on
app.listen(process.env.PORT || 3000, process.env.IP || "0.0.0.0", function(){
    console.log("App is running......Yesss!");
});




